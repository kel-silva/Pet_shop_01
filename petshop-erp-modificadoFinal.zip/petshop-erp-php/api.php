<?php
// ===================================================
// API BACKEND - PET SHOP ERP
// ===================================================

require_once 'config.php';

// Headers para permitir requisições
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Função para validar autenticação
function requireAuth() {
    if (!isset($_SESSION['store_id'])) {
        jsonResponse(['error' => 'Não autorizado'], 401);
    }
    return $_SESSION['store_id'];
}

// Pegar dados do POST
$data = json_decode(file_get_contents('php://input'), true) ?: [];
$action = $_GET['action'] ?? '';

$pdo = getDBConnection();

// ===================================================
// AUTENTICAÇÃO
// ===================================================

if ($action === 'login') {
    $username = trim($data['username'] ?? '');
    $password = $data['password'] ?? '';
    $storeName = trim($data['storeName'] ?? '');

    if (empty($username) || empty($password)) {
        jsonResponse(['error' => 'Preencha todos os campos'], 400);
    }

    $stmt = $pdo->prepare("SELECT * FROM stores WHERE name = ?");
    $stmt->execute([$username]);
    $store = $stmt->fetch();

    if (!$store || !password_verify($password, $store['password'])) {
        jsonResponse(['error' => 'Senha incorreta.'], 401);
    }

    // Verificar se a loja está ativa
    if (isset($store['active']) && $store['active'] == 0) {
        jsonResponse(['error' => 'Esta loja está inativa. Entre em contato com o administrador.'], 403);
    }

    $_SESSION['store_id'] = $store['id'];
    $_SESSION['store_name'] = $store['name'];
    $_SESSION['display_name'] = !empty($storeName) ? $storeName : $store['display_name'];

    jsonResponse([
        'success' => true,
        'storeName' => $_SESSION['display_name']
    ]);
}

if ($action === 'logout') {
    session_destroy();
    jsonResponse(['success' => true]);
}

// ===================================================
// ADMIN - GERENCIAMENTO DE LOJAS
// ===================================================

if ($action === 'admin_create_store') {
    $name = trim($data['name'] ?? '');
    $password = $data['password'] ?? '';

    if (empty($name) || empty($password)) {
        jsonResponse(['error' => 'Preencha todos os campos'], 400);
    }

    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    try {
        $stmt = $pdo->prepare("INSERT INTO stores (name, password, display_name, active) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $hashedPassword, ucfirst($name), 1]);
        jsonResponse(['success' => true, 'message' => 'Loja criada com sucesso']);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Loja já existe ou erro ao criar'], 400);
    }
}

if ($action === 'admin_list_stores') {
    $stmt = $pdo->query("SELECT id, name, display_name, active, created_at FROM stores ORDER BY name");
    jsonResponse(['stores' => $stmt->fetchAll()]);
}

if ($action === 'admin_delete_store') {
    $storeId = intval($data['id'] ?? 0);

    if ($storeId <= 0) {
        jsonResponse(['error' => 'ID inválido'], 400);
    }

    $stmt = $pdo->prepare("SELECT name FROM stores WHERE id = ?");
    $stmt->execute([$storeId]);
    $store = $stmt->fetch();

    if ($store && $store['name'] === 'admin') {
        jsonResponse(['error' => 'Não é possível deletar o admin'], 403);
    }

    $stmt = $pdo->prepare("DELETE FROM stores WHERE id = ?");
    $stmt->execute([$storeId]);

    jsonResponse(['success' => true]);
}

if ($action === 'admin_toggle_status') {
    $storeId = intval($data['id'] ?? 0);

    if ($storeId <= 0) {
        jsonResponse(['error' => 'ID inválido'], 400);
    }

    $stmt = $pdo->prepare("SELECT name, active FROM stores WHERE id = ?");
    $stmt->execute([$storeId]);
    $store = $stmt->fetch();

    if ($store && $store['name'] === 'admin') {
        jsonResponse(['error' => 'Não é possível desativar o admin'], 403);
    }

    $newStatus = $store['active'] == 1 ? 0 : 1;
    $stmt = $pdo->prepare("UPDATE stores SET active = ? WHERE id = ?");
    $stmt->execute([$newStatus, $storeId]);

    jsonResponse(['success' => true, 'newStatus' => $newStatus]);
}

if ($action === 'admin_update_store') {
    $storeId = intval($data['id'] ?? 0);
    $name = trim($data['name'] ?? '');
    $password = $data['password'] ?? '';

    if ($storeId <= 0 || empty($name)) {
        jsonResponse(['error' => 'Dados inválidos'], 400);
    }

    // Se senha foi fornecida, atualizar também
    if (!empty($password)) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("UPDATE stores SET name = ?, password = ?, display_name = ? WHERE id = ?");
        $stmt->execute([$name, $hashedPassword, ucfirst($name), $storeId]);
    } else {
        $stmt = $pdo->prepare("UPDATE stores SET name = ?, display_name = ? WHERE id = ?");
        $stmt->execute([$name, ucfirst($name), $storeId]);
    }

    jsonResponse(['success' => true, 'message' => 'Loja atualizada com sucesso']);
}

// ===================================================
// PETS
// ===================================================

if ($action === 'pets_list') {
    $storeId = requireAuth();

    $stmt = $pdo->prepare("SELECT * FROM pets WHERE store_id = ? ORDER BY name");
    $stmt->execute([$storeId]);

    jsonResponse(['pets' => $stmt->fetchAll()]);
}

if ($action === 'pets_save') {
    $storeId = requireAuth();

    $id = intval($data['id'] ?? 0);
    $name = trim($data['name'] ?? '');
    $owner = trim($data['owner'] ?? '');

    if (empty($name) || empty($owner)) {
        jsonResponse(['error' => 'Nome e Dono são obrigatórios'], 400);
    }

    if ($id > 0) {
        $stmt = $pdo->prepare("
            UPDATE pets SET
                name = ?, owner = ?, species = ?, breed = ?,
                gender = ?, phone = ?, email = ?, birth = ?, medical = ?
            WHERE id = ? AND store_id = ?
        ");
        $stmt->execute([
            $name,
            $owner,
            $data['species'] ?? '',
            $data['breed'] ?? '',
            $data['gender'] ?? '',
            $data['phone'] ?? '',
            $data['email'] ?? '',
            $data['birth'] ?? null,
            $data['medical'] ?? '',
            $id,
            $storeId
        ]);
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO pets (store_id, name, owner, species, breed, gender, phone, email, birth, medical)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $storeId,
            $name,
            $owner,
            $data['species'] ?? '',
            $data['breed'] ?? '',
            $data['gender'] ?? '',
            $data['phone'] ?? '',
            $data['email'] ?? '',
            $data['birth'] ?? null,
            $data['medical'] ?? ''
        ]);
    }

    jsonResponse(['success' => true]);
}

if ($action === 'pets_delete') {
    $storeId = requireAuth();
    $id = intval($data['id'] ?? 0);

    $stmt = $pdo->prepare("DELETE FROM pets WHERE id = ? AND store_id = ?");
    $stmt->execute([$id, $storeId]);

    jsonResponse(['success' => true]);
}

// ===================================================
// FUNCIONÁRIOS
// ===================================================

if ($action === 'staff_list') {
    $storeId = requireAuth();

    $stmt = $pdo->prepare("SELECT * FROM staff WHERE store_id = ? ORDER BY name");
    $stmt->execute([$storeId]);

    jsonResponse(['staff' => $stmt->fetchAll()]);
}

if ($action === 'staff_save') {
    $storeId = requireAuth();

    $id = intval($data['id'] ?? 0);
    $name = trim($data['name'] ?? '');

    if (empty($name)) {
        jsonResponse(['error' => 'Nome é obrigatório'], 400);
    }

    if ($id > 0) {
        $stmt = $pdo->prepare("
            UPDATE staff SET
                name = ?, cpf = ?, role = ?, commission = ?,
                salary = ?, phone = ?, email = ?, admission_date = ?
            WHERE id = ? AND store_id = ?
        ");
        $stmt->execute([
            $name,
            $data['cpf'] ?? '',
            $data['role'] ?? '',
            floatval($data['comm'] ?? 0),
            floatval($data['salary'] ?? 0),
            $data['phone'] ?? '',
            $data['email'] ?? '',
            $data['admission'] ?? null,
            $id,
            $storeId
        ]);
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO staff (store_id, name, cpf, role, commission, salary, phone, email, admission_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $storeId,
            $name,
            $data['cpf'] ?? '',
            $data['role'] ?? '',
            floatval($data['comm'] ?? 0),
            floatval($data['salary'] ?? 0),
            $data['phone'] ?? '',
            $data['email'] ?? '',
            $data['admission'] ?? null
        ]);
    }

    jsonResponse(['success' => true]);
}

if ($action === 'staff_delete') {
    $storeId = requireAuth();
    $id = intval($data['id'] ?? 0);

    $stmt = $pdo->prepare("DELETE FROM staff WHERE id = ? AND store_id = ?");
    $stmt->execute([$id, $storeId]);

    jsonResponse(['success' => true]);
}

// ===================================================
// ESTOQUE
// ===================================================

if ($action === 'stock_list') {
    $storeId = requireAuth();

    $stmt = $pdo->prepare("SELECT * FROM stock WHERE store_id = ? ORDER BY name");
    $stmt->execute([$storeId]);

    jsonResponse(['stock' => $stmt->fetchAll()]);
}

if ($action === 'stock_save') {
    $storeId = requireAuth();

    $id = intval($data['id'] ?? 0);
    $name = trim($data['name'] ?? '');
    $qty = intval($data['qty'] ?? 0);

    if (empty($name)) {
        jsonResponse(['error' => 'Nome é obrigatório'], 400);
    }

    if ($id > 0) {
        $stmt = $pdo->prepare("
            UPDATE stock SET
                name = ?, category = ?, quantity = ?, cost = ?, price = ?, min_stock = ?
            WHERE id = ? AND store_id = ?
        ");
        $stmt->execute([
            $name,
            $data['category'] ?? '',
            $qty,
            floatval($data['cost'] ?? 0),
            floatval($data['price'] ?? 0),
            intval($data['min'] ?? 5),
            $id,
            $storeId
        ]);
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO stock (store_id, name, category, quantity, cost, price, min_stock)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $storeId,
            $name,
            $data['category'] ?? '',
            $qty,
            floatval($data['cost'] ?? 0),
            floatval($data['price'] ?? 0),
            intval($data['min'] ?? 5)
        ]);
    }

    jsonResponse(['success' => true]);
}

if ($action === 'stock_delete') {
    $storeId = requireAuth();
    $id = intval($data['id'] ?? 0);

    $stmt = $pdo->prepare("DELETE FROM stock WHERE id = ? AND store_id = ?");
    $stmt->execute([$id, $storeId]);

    jsonResponse(['success' => true]);
}

// ===================================================
// SERVIÇOS CUSTOMIZADOS
// ===================================================

if ($action === 'services_list') {
    $storeId = requireAuth();

    $stmt = $pdo->prepare("SELECT * FROM custom_services WHERE store_id = ? ORDER BY name");
    $stmt->execute([$storeId]);

    jsonResponse(['services' => $stmt->fetchAll()]);
}

if ($action === 'services_save') {
    $storeId = requireAuth();

    $name = trim($data['name'] ?? '');
    $value = floatval($data['value'] ?? 0);

    if (empty($name) || $value <= 0) {
        jsonResponse(['error' => 'Nome e valor são obrigatórios'], 400);
    }

    $stmt = $pdo->prepare("INSERT INTO custom_services (store_id, name, default_value) VALUES (?, ?, ?)");
    $stmt->execute([$storeId, $name, $value]);

    jsonResponse(['success' => true]);
}

if ($action === 'services_delete') {
    $storeId = requireAuth();
    $name = trim($data['name'] ?? '');

    $stmt = $pdo->prepare("DELETE FROM custom_services WHERE store_id = ? AND name = ?");
    $stmt->execute([$storeId, $name]);

    jsonResponse(['success' => true]);
}

// ===================================================
// AGENDAMENTOS
// ===================================================

if ($action === 'appointments_list') {
    $storeId = requireAuth();

    $stmt = $pdo->prepare("SELECT * FROM appointments WHERE store_id = ? ORDER BY appointment_date, appointment_time");
    $stmt->execute([$storeId]);

    $appointments = $stmt->fetchAll();

    foreach ($appointments as &$appt) {
        $appt['services'] = json_decode($appt['services'], true);
        $appt['products'] = json_decode($appt['products'], true);
    }

    jsonResponse(['appointments' => $appointments]);
}

if ($action === 'appointments_save') {
    $storeId = requireAuth();

    $petId = intval($data['petId'] ?? 0);
    $date = $data['date'] ?? '';
    $time = $data['time'] ?? '';
    $services = $data['services'] ?? [];
    $products = $data['products'] ?? [];

    if (!$petId || !$date || !$time || empty($services)) {
        jsonResponse(['error' => 'Dados incompletos'], 400);
    }

    $totalValue = 0;
    foreach ($services as $service) {
        $totalValue += floatval($service['value'] ?? 0);
    }

    // Atualizar estoque
    foreach ($products as $product) {
        $stmt = $pdo->prepare("UPDATE stock SET quantity = quantity - ? WHERE id = ? AND store_id = ?");
        $stmt->execute([intval($product['qty']), intval($product['productId']), $storeId]);
    }

    // Salvar agendamento
    $stmt = $pdo->prepare("
        INSERT INTO appointments (store_id, pet_id, staff_id, appointment_date, appointment_time, services, products, total_value)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $storeId,
        $petId,
        !empty($data['staffId']) ? intval($data['staffId']) : null,
        $date,
        $time,
        json_encode($services),
        json_encode($products),
        $totalValue
    ]);

    jsonResponse(['success' => true]);
}

if ($action === 'appointments_delete') {
    $storeId = requireAuth();
    $id = intval($data['id'] ?? 0);

    $stmt = $pdo->prepare("DELETE FROM appointments WHERE id = ? AND store_id = ?");
    $stmt->execute([$id, $storeId]);

    jsonResponse(['success' => true]);
}

// ===================================================
// FINANCEIRO
// ===================================================

if ($action === 'finances_list') {
    $storeId = requireAuth();

    $stmt = $pdo->prepare("SELECT * FROM finances WHERE store_id = ? ORDER BY transaction_date DESC");
    $stmt->execute([$storeId]);

    jsonResponse(['finances' => $stmt->fetchAll()]);
}

if ($action === 'finances_save') {
    $storeId = requireAuth();

    $id = intval($data['id'] ?? 0);
    $type = $data['type'] ?? 'expense';
    $desc = trim($data['desc'] ?? '');
    $value = floatval($data['val'] ?? 0);
    $date = $data['date'] ?? '';

    if (empty($desc) || $value <= 0 || empty($date)) {
        jsonResponse(['error' => 'Preencha todos os campos'], 400);
    }

    if ($id > 0) {
        $stmt = $pdo->prepare("
            UPDATE finances SET type = ?, description = ?, value = ?, transaction_date = ?
            WHERE id = ? AND store_id = ?
        ");
        $stmt->execute([$type, $desc, $value, $date, $id, $storeId]);
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO finances (store_id, type, description, value, transaction_date)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$storeId, $type, $desc, $value, $date]);
    }

    jsonResponse(['success' => true]);
}

if ($action === 'finances_delete') {
    $storeId = requireAuth();
    $id = intval($data['id'] ?? 0);

    $stmt = $pdo->prepare("DELETE FROM finances WHERE id = ? AND store_id = ?");
    $stmt->execute([$id, $storeId]);

    jsonResponse(['success' => true]);
}

// ===================================================
// BACKUP
// ===================================================

if ($action === 'backup_export') {
    $storeId = requireAuth();

    $backup = [];
    $tables = ['pets', 'staff', 'stock', 'custom_services', 'appointments', 'finances'];

    foreach ($tables as $table) {
        $stmt = $pdo->prepare("SELECT * FROM $table WHERE store_id = ?");
        $stmt->execute([$storeId]);
        $backup[$table] = $stmt->fetchAll();
    }

    jsonResponse(['backup' => $backup]);
}

if ($action === 'backup_import') {
    $storeId = requireAuth();
    $backup = $data['backup'] ?? [];

    if (empty($backup)) {
        jsonResponse(['error' => 'Dados de backup inválidos'], 400);
    }

    try {
        $pdo->beginTransaction();

        // Limpar dados antigos
        $tables = ['finances', 'appointments', 'custom_services', 'stock', 'staff', 'pets'];
        foreach ($tables as $table) {
            $pdo->prepare("DELETE FROM $table WHERE store_id = ?")->execute([$storeId]);
        }

        // Restaurar dados
        foreach ($backup as $table => $rows) {
            if (!in_array($table, $tables)) continue;

            foreach ($rows as $row) {
                unset($row['id']);
                unset($row['created_at']);
                $row['store_id'] = $storeId;

                $columns = array_keys($row);
                $placeholders = array_fill(0, count($columns), '?');

                $sql = "INSERT INTO $table (" . implode(',', $columns) . ") VALUES (" . implode(',', $placeholders) . ")";
                $stmt = $pdo->prepare($sql);
                $stmt->execute(array_values($row));
            }
        }

        $pdo->commit();
        jsonResponse(['success' => true, 'message' => 'Backup restaurado com sucesso']);
    } catch (Exception $e) {
        $pdo->rollBack();
        jsonResponse(['error' => 'Erro ao restaurar backup: ' . $e->getMessage()], 500);
    }
}

// ===================================================
// DASHBOARD / ESTATÍSTICAS
// ===================================================

if ($action === 'dashboard_stats') {
    $storeId = requireAuth();
    $month = $data['month'] ?? date('Y-m');

    $stats = [];

    // Total de agendamentos
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM appointments WHERE store_id = ? AND strftime('%Y-%m', appointment_date) = ?");
    $stmt->execute([$storeId, $month]);
    $stats['appointments'] = $stmt->fetch()['count'];

    // Receita dos agendamentos
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(total_value), 0) as total FROM appointments WHERE store_id = ? AND strftime('%Y-%m', appointment_date) = ?");
    $stmt->execute([$storeId, $month]);
    $stats['revenue_appointments'] = $stmt->fetch()['total'];

    // Receitas extras
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(value), 0) as total FROM finances WHERE store_id = ? AND type = 'income' AND strftime('%Y-%m', transaction_date) = ?");
    $stmt->execute([$storeId, $month]);
    $stats['revenue_extra'] = $stmt->fetch()['total'];

    // Despesas
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(value), 0) as total FROM finances WHERE store_id = ? AND type = 'expense' AND strftime('%Y-%m', transaction_date) = ?");
    $stmt->execute([$storeId, $month]);
    $stats['expenses'] = $stmt->fetch()['total'];

    $stats['total_revenue'] = $stats['revenue_appointments'] + $stats['revenue_extra'];
    $stats['profit'] = $stats['total_revenue'] - $stats['expenses'];

    jsonResponse(['stats' => $stats]);
}

if ($action === 'dashboard_chart') {
    $storeId = requireAuth();

    $chartData = [
        'labels' => [],
        'revenue' => [],
        'expenses' => []
    ];

    // Meses em português
    $mesesAbrev = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

    for ($i = 5; $i >= 0; $i--) {
        $date = new DateTime();
        $date->modify("-$i month");
        $month = $date->format('Y-m');
        $monthNum = (int)$date->format('n') - 1; // 0-based index
        $label = $mesesAbrev[$monthNum];

        $chartData['labels'][] = $label;

        // Receita
        $stmt = $pdo->prepare("SELECT COALESCE(SUM(total_value), 0) as total FROM appointments WHERE store_id = ? AND strftime('%Y-%m', appointment_date) = ?");
        $stmt->execute([$storeId, $month]);
        $revenue = $stmt->fetch()['total'];

        $stmt = $pdo->prepare("SELECT COALESCE(SUM(value), 0) as total FROM finances WHERE store_id = ? AND type = 'income' AND strftime('%Y-%m', transaction_date) = ?");
        $stmt->execute([$storeId, $month]);
        $revenue += $stmt->fetch()['total'];

        $chartData['revenue'][] = $revenue;

        // Despesas
        $stmt = $pdo->prepare("SELECT COALESCE(SUM(value), 0) as total FROM finances WHERE store_id = ? AND type = 'expense' AND strftime('%Y-%m', transaction_date) = ?");
        $stmt->execute([$storeId, $month]);
        $chartData['expenses'][] = $stmt->fetch()['total'];
    }

    jsonResponse(['chartData' => $chartData]);
}

// Se chegou aqui, ação inválida
jsonResponse(['error' => 'Ação inválida: ' . $action], 400);
?>
