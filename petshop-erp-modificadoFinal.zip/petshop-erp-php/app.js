// ===================================================
// APLICAÇÃO PRINCIPAL - PET SHOP ERP
// ===================================================

const app = {
    store: null,
    storeName: null,
    adminMode: false,
    editMode: {},
    chartInstance: null,
    toastEl: null,
    currentAgendaFilter: null,
    servicesCounter: 0,
    productsCounter: 0,
    documentType: 'cpf', // 'cpf' ou 'cnpj'
    cachedData: {
        pets: [],
        staff: [],
        stock: [],
        services: [],
        appointments: [],
        finances: []
    },
    servicesList: [
        { name: 'Banho', value: 40 },
        { name: 'Tosa', value: 60 },
        { name: 'Banho e Tosa', value: 90 },
        { name: 'Consulta Veterinária', value: 100 },
        { name: 'Vacinação', value: 80 },
        { name: 'Exame', value: 120 },
        { name: 'Castração', value: 250 },
        { name: 'Cirurgia', value: 500 },
        { name: 'Hospedagem', value: 50 },
        { name: 'Adestramento', value: 150 }
    ],

    // ==================== INICIALIZAÇÃO ====================
    init: function() {
        this.toastEl = new bootstrap.Toast(document.getElementById('toast'));
        const today = new Date().toISOString().split('T')[0];
        document.querySelectorAll('input[type="date"]').forEach(i => i.value = today);

        document.addEventListener('keydown', (e) => {
            if (e.key === 'F12') {
                e.preventDefault();
                this.toggleAdminButton();
            }
        });

        this.populateMonthFilter();
        this.applyPhoneMasks();
        this.applyCpfCnpjMask();
        this.loadSavedStoreName();
    },

    // ==================== HELPERS ====================
    async apiCall(action, data = {}) {
        try {
            const response = await fetch(`api.php?action=${action}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (response.status === 401) {
                this.toast('Sessão expirada. Faça login novamente.');
                setTimeout(() => this.nav('login-screen'), 2000);
                return { error: 'Sessão expirada' };
            }

            return result;
        } catch (error) {
            this.toast('Erro de conexão com o servidor');
            console.error('Erro na API:', error);
            return { error: 'Erro de conexão' };
        }
    },

    toast: function(msg) {
        document.getElementById('toast-message').innerText = msg;
        this.toastEl.show();
    },

    formatCurrency: function(input) {
        let v = input.value.replace(/\D/g, "");
        input.value = (Number(v) / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2 });
    },

    parseCurrency: function(str) {
        return str ? Number(str.replace(/\./g, '').replace(',', '.')) : 0;
    },

    togglePassword: function(id, btn) {
        const inp = document.getElementById(id);
        const icon = btn.querySelector('i');
        if (inp.type === "password") {
            inp.type = "text";
            icon.className = "bi bi-eye-slash";
        } else {
            inp.type = "password";
            icon.className = "bi bi-eye";
        }
    },

    toggleAdminButton: function() {
        const btn = document.getElementById('btn-super-admin');
        this.adminMode = !this.adminMode;
        btn.classList.toggle('visible', this.adminMode);
        this.toast(this.adminMode ? "Modo Admin Ativado" : "Modo Admin Desativado");
    },

    saveStoreName: function() {
        const name = document.getElementById('login-store-name').value.trim();
        if (!name) {
            return this.toast("Digite o nome da loja primeiro!");
        }

        localStorage.setItem('saved_store_name', name);
        document.getElementById('login-store-name').disabled = true;
        document.getElementById('btn-save-store-name').classList.add('d-none');
        document.getElementById('btn-edit-store-name').classList.remove('d-none');
        this.toast("Nome da loja salvo com sucesso!");
    },

    editStoreName: function() {
        document.getElementById('login-store-name').disabled = false;
        document.getElementById('login-store-name').focus();
        document.getElementById('btn-save-store-name').classList.remove('d-none');
        document.getElementById('btn-edit-store-name').classList.add('d-none');
    },

    loadSavedStoreName: function() {
        const saved = localStorage.getItem('saved_store_name');
        if (saved) {
            document.getElementById('login-store-name').value = saved;
            document.getElementById('login-store-name').disabled = true;
            document.getElementById('btn-save-store-name').classList.add('d-none');
            document.getElementById('btn-edit-store-name').classList.remove('d-none');
        }
    },

    applyPhoneMasks: function() {
        document.addEventListener('input', function(e) {
            if(e.target.classList.contains('phone-mask')) {
                app.phoneMask(e.target);
            }
        });
    },

    phoneMask: function(input) {
        let value = input.value.replace(/\D/g, '');

        if(value.length <= 10) {
            value = value.replace(/^(\d{2})(\d)/g, '($1) $2');
            value = value.replace(/(\d)(\d{4})$/, '$1-$2');
        } else {
            value = value.replace(/^(\d{2})(\d)/g, '($1) $2');
            value = value.replace(/(\d)(\d{4})$/, '$1-$2');
        }

        input.value = value;
    },

    applyCpfCnpjMask: function() {
        const cpfInput = document.getElementById('stf-cpf');
        if (cpfInput) {
            cpfInput.addEventListener('input', () => {
                this.cpfCnpjMask(cpfInput);
            });
        }
    },

    cpfCnpjMask: function(input) {
        let value = input.value.replace(/\D/g, '');

        if (this.documentType === 'cpf') {
            // Máscara CPF: 000.000.000-00
            if (value.length <= 11) {
                value = value.replace(/(\d{3})(\d)/, '$1.$2');
                value = value.replace(/(\d{3})(\d)/, '$1.$2');
                value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
            }
        } else {
            // Máscara CNPJ: 00.000.000/0000-00
            if (value.length <= 14) {
                value = value.replace(/(\d{2})(\d)/, '$1.$2');
                value = value.replace(/(\d{3})(\d)/, '$1.$2');
                value = value.replace(/(\d{3})(\d)/, '$1/$2');
                value = value.replace(/(\d{4})(\d{1,2})$/, '$1-$2');
            }
        }

        input.value = value;
    },

    toggleDocumentType: function() {
        const cpfInput = document.getElementById('stf-cpf');
        const label = document.getElementById('doc-label');
        const toggleBtn = document.getElementById('toggle-doc-type');

        if (this.documentType === 'cpf') {
            this.documentType = 'cnpj';
            label.textContent = 'CNPJ';
            cpfInput.placeholder = '00.000.000/0000-00';
            cpfInput.maxLength = '18';
            toggleBtn.innerHTML = '<i class="bi bi-arrow-left-right"></i> Trocar para CPF';
        } else {
            this.documentType = 'cpf';
            label.textContent = 'CPF';
            cpfInput.placeholder = '000.000.000-00';
            cpfInput.maxLength = '14';
            toggleBtn.innerHTML = '<i class="bi bi-arrow-left-right"></i> Trocar para CNPJ';
        }

        // Limpar campo e reaplicar máscara
        cpfInput.value = '';
    },

    populateMonthFilter: function() {
        const select = document.getElementById('month-filter');
        if (!select) return;

        const now = new Date();
        select.innerHTML = '';

        for (let i = 0; i < 12; i++) {
            const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
            const value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
            const label = d.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
            const option = document.createElement('option');
            option.value = value;
            option.textContent = label.charAt(0).toUpperCase() + label.slice(1);
            if (i === 0) option.selected = true;
            select.appendChild(option);
        }
    },

    nav: function(id) {
        window.scrollTo(0, 0);
        document.querySelectorAll('.screen').forEach(el => el.classList.remove('active'));
        document.getElementById(id).classList.add('active');

        if(id === 'admin-screen') this.renderAdminStores();

        this.cancelEdit('pet');
        this.cancelEdit('stock');
        this.cancelEdit('staff');
        this.cancelEdit('finance');
        this.cancelEdit('agenda');

        if(id === 'main-screen') {
            this.updateDashboard();
            this.checkTodayAppointments();
            setTimeout(() => this.renderChart(), 100);
        }
        if(id === 'agenda-screen') {
            this.currentAgendaFilter = null;
            document.getElementById('agenda-filter-date').value = '';
            this.renderAgendaList();
            this.loadAgendaOptions();
        }
        if(id === 'pets-screen') this.renderPets();
        if(id === 'stock-screen') this.renderStock();
        if(id === 'staff-screen') this.renderStaff();
        if(id === 'finance-screen') {
            this.renderExpenses();
            this.updateFinanceButton();
        }
    },

    prepareForm: function(type) {
        this.editMode[type] = false;
        const container = document.getElementById(`${type}-form-container`);
        container.classList.remove('d-none');
        container.scrollIntoView({ behavior: 'smooth', block: 'center' });

        if(type === 'pet') {
            document.getElementById('pet-id').value = '';
            document.getElementById('pet-name').value = '';
            document.getElementById('pet-owner').value = '';
            document.getElementById('pet-species').value = 'Cão';
            document.getElementById('pet-breed').value = '';
            document.getElementById('pet-gender').value = '';
            document.getElementById('pet-phone').value = '';
            document.getElementById('pet-email').value = '';
            document.getElementById('pet-birth').value = '';
            document.getElementById('pet-medical').value = '';
        }
        else if(type === 'stock') {
            document.getElementById('stk-id').value = '';
            document.getElementById('stk-name').value = '';
            document.getElementById('stk-category').value = 'Higiene';
            document.getElementById('stk-qty').value = '';
            document.getElementById('stk-cost').value = '';
            document.getElementById('stk-price').value = '';
            document.getElementById('stk-min').value = '5';
        }
        else if(type === 'staff') {
            document.getElementById('stf-id').value = '';
            document.getElementById('stf-name').value = '';
            document.getElementById('stf-cpf').value = '';
            document.getElementById('stf-role').value = 'Banhista';
            document.getElementById('stf-comm').value = '';
            document.getElementById('stf-salary').value = '';
            document.getElementById('stf-phone').value = '';
            document.getElementById('stf-email').value = '';
            document.getElementById('stf-admission').value = '';
        }
        else if(type === 'agenda') {
            this.loadAgendaOptions();
            document.getElementById('ag-time').value = '09:00';
            this.servicesCounter = 0;
            this.productsCounter = 0;
            document.getElementById('services-grid').innerHTML = '';
            document.getElementById('products-grid').innerHTML = '';
            this.addService();
        }
    },

    cancelEdit: function(type) {
        this.editMode[type] = false;
        const container = document.getElementById(`${type}-form-container`);
        if(container) container.classList.add('d-none');

        if(type === 'finance') {
            document.getElementById('btn-cancel-fin').classList.add('d-none');
            document.getElementById('fin-id').value = '';
            this.updateFinanceButton();
        }
    },

    // ==================== AUTENTICAÇÃO ====================
    async login() {
        const username = document.getElementById('login-user').value.trim();
        const password = document.getElementById('login-pass').value;
        const storeName = document.getElementById('login-store-name').value.trim();
        const msg = document.getElementById('login-msg');

        if (!username || !password) {
            msg.innerText = "Digite o login e senha.";
            return;
        }

        const result = await this.apiCall('login', { username, password, storeName });

        if (result.error) {
            msg.innerText = result.error;
        } else {
            this.storeName = result.storeName;
            document.getElementById('badge-store').innerText = this.storeName.toUpperCase();
            await this.loadCustomServices();
            this.nav('main-screen');
        }
    },

    async logout() {
        await this.apiCall('logout');
        this.storeName = null;
        if (this.chartInstance) {
            this.chartInstance.destroy();
            this.chartInstance = null;
        }
        this.servicesList = this.servicesList.filter(s => !s.custom);
        this.nav('login-screen');
    },

    // ==================== ADMIN ====================
    async saveStore() {
        const editId = document.getElementById('admin-edit-id').value;
        const name = document.getElementById('admin-new-store').value.trim();
        const password = document.getElementById('admin-new-pass').value;

        if (!name) {
            return this.toast("Preencha o nome da loja!");
        }

        // Se está editando
        if (editId) {
            const result = await this.apiCall('admin_update_store', {
                id: parseInt(editId),
                name,
                password
            });

            if (result.success) {
                this.cancelEditStore();
                this.renderAdminStores();
                this.toast('Loja atualizada com sucesso!');
            } else {
                this.toast(result.error || 'Erro ao atualizar loja');
            }
        } else {
            // Criando nova loja
            if (!password) {
                return this.toast("Preencha a senha!");
            }

            const result = await this.apiCall('admin_create_store', { name, password });

            if (result.success) {
                document.getElementById('admin-new-store').value = '';
                document.getElementById('admin-new-pass').value = '';
                this.renderAdminStores();
                this.toast(`Loja ${name} criada com sucesso!`);
            } else {
                this.toast(result.error || 'Erro ao criar loja');
            }
        }
    },

    editStore: function(id, name) {
        document.getElementById('admin-edit-id').value = id;
        document.getElementById('admin-new-store').value = name;
        document.getElementById('admin-new-pass').value = '';
        document.getElementById('admin-new-pass').placeholder = 'Nova senha (deixe vazio para manter)';
        document.getElementById('admin-form-title').innerText = 'Editar Loja';
        document.getElementById('btn-save-store').innerHTML = '<i class="bi bi-check-circle"></i> SALVAR';
        document.getElementById('btn-cancel-edit-store').classList.remove('d-none');

        // Scroll para o formulário
        document.querySelector('.form-section').scrollIntoView({ behavior: 'smooth', block: 'start' });
    },

    cancelEditStore: function() {
        document.getElementById('admin-edit-id').value = '';
        document.getElementById('admin-new-store').value = '';
        document.getElementById('admin-new-pass').value = '';
        document.getElementById('admin-new-pass').placeholder = 'Senha Inicial';
        document.getElementById('admin-form-title').innerText = 'Cadastrar Nova Loja';
        document.getElementById('btn-save-store').innerHTML = '<i class="bi bi-plus-circle"></i> CRIAR';
        document.getElementById('btn-cancel-edit-store').classList.add('d-none');
    },

    async toggleStoreStatus(id) {
        const result = await this.apiCall('admin_toggle_status', { id });

        if (result.success) {
            this.renderAdminStores();
            const statusText = result.newStatus == 1 ? 'ativada' : 'desativada';
            this.toast(`Loja ${statusText} com sucesso!`);
        } else {
            this.toast(result.error || 'Erro ao alterar status');
        }
    },

    async deleteStore(id) {
        if (!confirm('Apagar loja e todos os dados?')) return;

        const result = await this.apiCall('admin_delete_store', { id });

        if (result.success) {
            this.renderAdminStores();
            this.toast("Loja removida com sucesso.");
        }
    },

    async renderAdminStores() {
        const tbody = document.getElementById('admin-stores-list');
        const result = await this.apiCall('admin_list_stores');

        if (!result.stores || result.stores.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">Nenhuma loja cadastrada.</td></tr>';
            return;
        }

        tbody.innerHTML = result.stores.map(s => {
            const date = new Date(s.created_at);
            const isActive = s.active == 1;
            const isAdmin = s.name === 'admin';
            const statusBadge = isActive
                ? '<span class="badge bg-success">Ativo</span>'
                : '<span class="badge bg-danger">Inativo</span>';
            const toggleBtnText = isActive ? 'Desativar' : 'Ativar';
            const toggleBtnClass = isActive ? 'btn-warning' : 'btn-success';

            return `
                <tr>
                    <td><strong>${s.name}</strong></td>
                    <td>${date.toLocaleString('pt-BR')}</td>
                    <td>${statusBadge}</td>
                    <td>
                        ${!isAdmin ? `
                            <button class="btn btn-sm ${toggleBtnClass}" onclick="app.toggleStoreStatus(${s.id})" title="Alternar status">
                                <i class="bi bi-toggle-${isActive ? 'on' : 'off'}"></i> ${toggleBtnText}
                            </button>
                        ` : ''}
                        <button class="btn btn-sm btn-primary" onclick="app.editStore(${s.id}, '${s.name.replace(/'/g, "\\'")}')">
                            <i class="bi bi-pencil"></i> Editar
                        </button>
                        ${!isAdmin ? `
                            <button class="btn btn-sm btn-danger" onclick="app.deleteStore(${s.id})">
                                <i class="bi bi-trash"></i> Excluir
                            </button>
                        ` : ''}
                    </td>
                </tr>
            `;
        }).join('');
    },

    // ==================== PETS ====================
    async renderPets() {
        const list = document.getElementById('pets-list');
        const result = await this.apiCall('pets_list');

        if (!result.pets || result.pets.length === 0) {
            list.innerHTML = '<div class="empty-state"><div class="empty-icon"><i class="bi bi-heart-pulse"></i></div><p>Nenhum pet cadastrado ainda.</p></div>';
            return;
        }

        this.cachedData.pets = result.pets;

        list.innerHTML = result.pets.map(p => `
            <div class="list-item">
                <div class="d-flex justify-content-between align-items-start mb-2 flex-wrap gap-2">
                    <div>
                        <h5 class="mb-1"><i class="bi bi-heart-fill text-danger"></i> ${p.name}</h5>
                        <span class="badge bg-success">${p.owner}</span>
                        ${p.species ? `<span class="badge bg-info ms-1">${p.species}</span>` : ''}
                        ${p.gender ? `<span class="badge bg-secondary ms-1">${p.gender}</span>` : ''}
                    </div>
                </div>
                <div class="small text-muted">
                    ${p.breed ? `<div><strong>Raça:</strong> ${p.breed}</div>` : ''}
                    ${p.phone ? `<div><strong>Telefone:</strong> ${p.phone}</div>` : ''}
                    ${p.email ? `<div><strong>E-mail:</strong> ${p.email}</div>` : ''}
                    ${p.birth ? `<div><strong>Nascimento:</strong> ${new Date(p.birth + 'T00:00:00').toLocaleDateString('pt-BR')}</div>` : ''}
                    ${p.medical ? `<div class="text-primary mt-2"><strong>Prontuário:</strong> ${p.medical}</div>` : ''}
                </div>
                <div class="d-flex gap-2 mt-3">
                    <button class="btn btn-sm btn-primary flex-fill" onclick="app.editPet(${p.id})">
                        <i class="bi bi-pencil"></i> Editar
                    </button>
                    <button class="btn btn-sm btn-danger flex-fill" onclick="app.deletePet(${p.id})">
                        <i class="bi bi-trash"></i> Excluir
                    </button>
                </div>
            </div>
        `).join('');
    },

    async savePet() {
        const id = parseInt(document.getElementById('pet-id').value) || 0;
        const name = document.getElementById('pet-name').value.trim();
        const owner = document.getElementById('pet-owner').value.trim();

        if (!name || !owner) return this.toast("Nome e Dono obrigatórios!");

        const petData = {
            id: id > 0 ? id : undefined,
            name,
            owner,
            species: document.getElementById('pet-species').value,
            breed: document.getElementById('pet-breed').value.trim(),
            gender: document.getElementById('pet-gender').value,
            phone: document.getElementById('pet-phone').value.trim(),
            email: document.getElementById('pet-email').value.trim(),
            birth: document.getElementById('pet-birth').value,
            medical: document.getElementById('pet-medical').value.trim()
        };

        const result = await this.apiCall('pets_save', petData);

        if (result.success) {
            this.toast(id > 0 ? "Pet atualizado!" : "Pet cadastrado!");
            this.cancelEdit('pet');
            this.renderPets();
            this.loadAgendaOptions();
        } else {
            this.toast(result.error || 'Erro ao salvar pet');
        }
    },

    editPet: function(id) {
        const p = this.cachedData.pets.find(x => x.id === id);
        if (!p) return;

        this.editMode['pet'] = true;
        document.getElementById('pet-id').value = p.id;
        document.getElementById('pet-name').value = p.name;
        document.getElementById('pet-owner').value = p.owner;
        document.getElementById('pet-species').value = p.species || 'Cão';
        document.getElementById('pet-breed').value = p.breed || '';
        document.getElementById('pet-gender').value = p.gender || '';
        document.getElementById('pet-phone').value = p.phone || '';
        document.getElementById('pet-email').value = p.email || '';
        document.getElementById('pet-birth').value = p.birth || '';
        document.getElementById('pet-medical').value = p.medical || '';

        document.getElementById('pet-form-container').classList.remove('d-none');
        document.getElementById('pet-form-container').scrollIntoView({ behavior: 'smooth', block: 'center' });
    },

    async deletePet(id) {
        if (!confirm("Tem certeza que deseja excluir este pet?")) return;

        const result = await this.apiCall('pets_delete', { id });

        if (result.success) {
            this.renderPets();
            this.toast("Pet excluído com sucesso.");
        }
    },

    // ==================== STAFF ====================
    async renderStaff() {
        const list = document.getElementById('staff-list');
        const result = await this.apiCall('staff_list');

        if (!result.staff || result.staff.length === 0) {
            list.innerHTML = '<div class="empty-state"><div class="empty-icon"><i class="bi bi-people"></i></div><p>Nenhum funcionário cadastrado.</p></div>';
            return;
        }

        this.cachedData.staff = result.staff;

        list.innerHTML = result.staff.map(s => `
            <div class="list-item">
                <div class="d-flex justify-content-between align-items-start mb-2 flex-wrap gap-2">
                    <div>
                        <h5 class="mb-1"><i class="bi bi-person-badge text-info"></i> ${s.name}</h5>
                        <span class="badge bg-info">${s.role || 'Funcionário'}</span>
                        ${s.commission ? `<span class="badge bg-warning ms-2">${s.commission}% Comissão</span>` : ''}
                    </div>
                    ${s.salary ? `<span class="badge bg-success">R$ ${parseFloat(s.salary).toFixed(2)}</span>` : ''}
                </div>
                <div class="small text-muted">
                    ${s.cpf ? `<div><strong>CPF:</strong> ${s.cpf}</div>` : ''}
                    ${s.phone ? `<div><strong>Telefone:</strong> ${s.phone}</div>` : ''}
                    ${s.email ? `<div><strong>E-mail:</strong> ${s.email}</div>` : ''}
                    ${s.admission_date ? `<div><strong>Admissão:</strong> ${new Date(s.admission_date + 'T00:00:00').toLocaleDateString('pt-BR')}</div>` : ''}
                </div>
                <div class="d-flex gap-2 mt-3">
                    <button class="btn btn-sm btn-primary flex-fill" onclick="app.editStaff(${s.id})">
                        <i class="bi bi-pencil"></i> Editar
                    </button>
                    <button class="btn btn-sm btn-danger flex-fill" onclick="app.deleteStaff(${s.id})">
                        <i class="bi bi-trash"></i> Excluir
                    </button>
                </div>
            </div>
        `).join('');
    },

    async saveStaff() {
        const id = parseInt(document.getElementById('stf-id').value) || 0;
        const name = document.getElementById('stf-name').value.trim();

        if (!name) return this.toast("Nome é obrigatório!");

        const staffData = {
            id: id > 0 ? id : undefined,
            name,
            cpf: document.getElementById('stf-cpf').value.trim(),
            role: document.getElementById('stf-role').value,
            comm: parseFloat(document.getElementById('stf-comm').value) || 0,
            salary: this.parseCurrency(document.getElementById('stf-salary').value),
            phone: document.getElementById('stf-phone').value.trim(),
            email: document.getElementById('stf-email').value.trim(),
            admission: document.getElementById('stf-admission').value
        };

        const result = await this.apiCall('staff_save', staffData);

        if (result.success) {
            this.toast(id > 0 ? "Funcionário atualizado!" : "Funcionário cadastrado!");
            this.cancelEdit('staff');
            this.renderStaff();
            this.loadAgendaOptions();
        } else {
            this.toast(result.error || 'Erro ao salvar funcionário');
        }
    },

    editStaff: function(id) {
        const s = this.cachedData.staff.find(x => x.id === id);
        if (!s) return;

        this.editMode['staff'] = true;
        document.getElementById('stf-id').value = s.id;
        document.getElementById('stf-name').value = s.name;
        document.getElementById('stf-cpf').value = s.cpf || '';
        document.getElementById('stf-role').value = s.role || 'Banhista';
        document.getElementById('stf-comm').value = s.commission || '';
        document.getElementById('stf-salary').value = s.salary ? parseFloat(s.salary).toFixed(2).replace('.', ',') : '';
        document.getElementById('stf-phone').value = s.phone || '';
        document.getElementById('stf-email').value = s.email || '';
        document.getElementById('stf-admission').value = s.admission_date || '';

        document.getElementById('staff-form-container').classList.remove('d-none');
        document.getElementById('staff-form-container').scrollIntoView({ behavior: 'smooth', block: 'center' });
    },

    async deleteStaff(id) {
        if (!confirm("Excluir funcionário?")) return;

        const result = await this.apiCall('staff_delete', { id });

        if (result.success) {
            this.renderStaff();
            this.toast("Funcionário excluído.");
        }
    },

    // ==================== STOCK ====================
    async renderStock() {
        const list = document.getElementById('stock-list');
        const result = await this.apiCall('stock_list');

        if (!result.stock || result.stock.length === 0) {
            list.innerHTML = '<div class="empty-state"><div class="empty-icon"><i class="bi bi-box-seam"></i></div><p>Estoque vazio.</p></div>';
            return;
        }

        this.cachedData.stock = result.stock;

        list.innerHTML = result.stock.map(item => {
            const low = item.quantity <= (item.min_stock || 5);
            return `
                <div class="list-item ${low ? 'low-stock' : ''}">
                    <div class="d-flex justify-content-between align-items-start mb-2 flex-wrap gap-2">
                        <div>
                            <h5 class="mb-1"><i class="bi bi-box text-warning"></i> ${item.name}</h5>
                            ${item.category ? `<span class="badge bg-secondary">${item.category}</span>` : ''}
                        </div>
                        <span class="badge ${low ? 'bg-danger' : 'bg-success'}">
                            Qtd: ${item.quantity}
                        </span>
                    </div>
                    <div class="small text-muted">
                        ${item.cost ? `<div>Custo: R$ ${parseFloat(item.cost).toFixed(2)}</div>` : ''}
                        ${item.price ? `<div>Preço Venda: R$ ${parseFloat(item.price).toFixed(2)}</div>` : ''}
                        ${low ? '<div class="text-danger mt-1"><i class="bi bi-exclamation-triangle"></i> Estoque Baixo</div>' : ''}
                    </div>
                    <div class="d-flex gap-2 mt-3">
                        <button class="btn btn-sm btn-primary flex-fill" onclick="app.editProduct(${item.id})">
                            <i class="bi bi-pencil"></i> Editar
                        </button>
                        <button class="btn btn-sm btn-danger flex-fill" onclick="app.deleteProduct(${item.id})">
                            <i class="bi bi-trash"></i> Excluir
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    },

    async saveProduct() {
        const id = parseInt(document.getElementById('stk-id').value) || 0;
        const name = document.getElementById('stk-name').value.trim();
        const qty = parseInt(document.getElementById('stk-qty').value);

        if (!name || isNaN(qty)) return this.toast("Nome e quantidade são obrigatórios!");

        const productData = {
            id: id > 0 ? id : undefined,
            name,
            category: document.getElementById('stk-category').value,
            qty,
            cost: this.parseCurrency(document.getElementById('stk-cost').value),
            price: this.parseCurrency(document.getElementById('stk-price').value),
            min: parseInt(document.getElementById('stk-min').value) || 5
        };

        const result = await this.apiCall('stock_save', productData);

        if (result.success) {
            this.toast(id > 0 ? "Produto atualizado!" : "Produto cadastrado!");
            this.cancelEdit('stock');
            this.renderStock();
            this.loadAgendaOptions();
        } else {
            this.toast(result.error || 'Erro ao salvar produto');
        }
    },

    editProduct: function(id) {
        const item = this.cachedData.stock.find(x => x.id === id);
        if (!item) return;

        this.editMode['stock'] = true;
        document.getElementById('stk-id').value = item.id;
        document.getElementById('stk-name').value = item.name;
        document.getElementById('stk-category').value = item.category || 'Higiene';
        document.getElementById('stk-qty').value = item.quantity;
        document.getElementById('stk-cost').value = (item.cost || 0).toFixed(2).replace('.', ',');
        document.getElementById('stk-price').value = (item.price || 0).toFixed(2).replace('.', ',');
        document.getElementById('stk-min').value = item.min_stock || 5;

        document.getElementById('stock-form-container').classList.remove('d-none');
        document.getElementById('stock-form-container').scrollIntoView({ behavior: 'smooth', block: 'center' });
    },

    async deleteProduct(id) {
        if (!confirm("Excluir produto?")) return;

        const result = await this.apiCall('stock_delete', { id });

        if (result.success) {
            this.renderStock();
            this.toast("Produto excluído.");
        }
    },

    // ==================== SERVIÇOS CUSTOMIZADOS ====================
    async loadCustomServices() {
        const result = await this.apiCall('services_list');

        if (result.services && result.services.length > 0) {
            this.servicesList = this.servicesList.filter(s => !s.custom);
            result.services.forEach(s => {
                this.servicesList.push({
                    name: s.name,
                    value: parseFloat(s.default_value),
                    custom: true
                });
            });
        }
    },

    async saveNewService() {
        const name = document.getElementById('new-service-name').value.trim();
        const value = this.parseCurrency(document.getElementById('new-service-value').value);

        if (!name || isNaN(value)) {
            return this.toast("Preencha nome e valor do serviço!");
        }

        if (this.servicesList.find(s => s.name.toLowerCase() === name.toLowerCase())) {
            return this.toast("Serviço já existe na lista!");
        }

        const result = await this.apiCall('services_save', { name, value });

        if (result.success) {
            await this.loadCustomServices();
            document.getElementById('new-service-name').value = '';
            document.getElementById('new-service-value').value = '';
            this.renderCustomServicesList();
            this.toast("Serviço adicionado com sucesso!");
        } else {
            this.toast(result.error || 'Erro ao adicionar serviço');
        }
    },

    async deleteCustomService(serviceName) {
        if (!confirm(`Excluir serviço "${serviceName}"?`)) return;

        const result = await this.apiCall('services_delete', { name: serviceName });

        if (result.success) {
            await this.loadCustomServices();
            this.renderCustomServicesList();
            this.toast("Serviço excluído com sucesso!");
        }
    },

    async deleteServiceFromSelect(id) {
        const select = document.querySelector(`.service-select[data-id="${id}"]`);
        if (!select || !select.value) {
            return this.toast("Selecione um serviço primeiro!");
        }

        const serviceName = select.value;
        const service = this.servicesList.find(s => s.name === serviceName);

        if (!service || !service.custom) {
            return this.toast("Só é possível excluir serviços personalizados!");
        }

        if (!confirm(`Excluir o serviço "${serviceName}" permanentemente da lista?`)) return;

        const result = await this.apiCall('services_delete', { name: serviceName });

        if (result.success) {
            await this.loadCustomServices();
            this.toast("Serviço excluído com sucesso!");
            this.reloadAllServiceSelects();
        }
    },

    reloadAllServiceSelects: function() {
        const options = this.servicesList.map(s =>
            `<option value="${s.name}" data-value="${s.value}">${s.name}</option>`
        ).join('');

        document.querySelectorAll('.service-select').forEach(select => {
            const currentValue = select.value;
            select.innerHTML = `<option value="">Selecione...</option>${options}`;

            if (currentValue && this.servicesList.find(s => s.name === currentValue)) {
                select.value = currentValue;
            }
        });
    },

    renderCustomServicesList: function() {
        const container = document.getElementById('custom-services-list');
        const customServices = this.servicesList.filter(s => s.custom);

        if (customServices.length === 0) {
            container.innerHTML = '<p class="text-muted text-center">Nenhum serviço personalizado cadastrado.</p>';
            return;
        }

        container.innerHTML = customServices.map(s => `
            <div class="custom-service-item">
                <div>
                    <strong>${s.name}</strong>
                    <span class="text-muted ms-2">R$ ${s.value.toFixed(2)}</span>
                </div>
                <button class="btn btn-sm btn-danger" onclick="app.deleteCustomService('${s.name.replace(/'/g, "\\'")}')">
                    <i class="bi bi-trash"></i>
                </button>
            </div>
        `).join('');
    },

    // ==================== AGENDAMENTOS - SERVIÇOS E PRODUTOS ====================
    addService: function() {
        this.servicesCounter++;
        const id = this.servicesCounter;
        const grid = document.getElementById('services-grid');

        const options = this.servicesList.map(s =>
            `<option value="${s.name}" data-value="${s.value}">${s.name}</option>`
        ).join('');

        const div = document.createElement('div');
        div.className = 'service-item';
        div.id = `service-${id}`;
        div.innerHTML = `
            <div class="row align-items-end">
                <div class="col-md-5 mb-2">
                    <label class="form-label small">Serviço</label>
                    <div class="input-group input-group-sm">
                        <select class="form-select service-select" data-id="${id}" onchange="app.updateServicePrice(${id})">
                            <option value="">Selecione...</option>
                            ${options}
                        </select>
                        <button class="btn btn-outline-success" type="button" data-bs-toggle="modal" data-bs-target="#addServiceModal" onclick="app.renderCustomServicesList()" title="Gerenciar serviços">
                            <i class="bi bi-plus-lg"></i>
                        </button>
                        <button class="btn btn-outline-danger" type="button" onclick="app.deleteServiceFromSelect(${id})" title="Excluir serviço selecionado da lista">
                            <i class="bi bi-dash-lg"></i>
                        </button>
                    </div>
                </div>
                <div class="col-md-5 mb-2">
                    <label class="form-label small">Valor (R$)</label>
                    <input type="text" class="form-control form-control-sm service-value" data-id="${id}" placeholder="0,00" onkeyup="app.formatCurrency(this); app.calculateServicesTotal()">
                </div>
                <div class="col-md-2 mb-2">
                    <button class="btn btn-sm btn-danger w-100" onclick="app.removeService(${id})">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            </div>
        `;

        grid.appendChild(div);
    },

    removeService: function(id) {
        const elem = document.getElementById(`service-${id}`);
        if (elem) {
            elem.remove();
            this.calculateServicesTotal();
        }
    },

    updateServicePrice: function(id) {
        const select = document.querySelector(`.service-select[data-id="${id}"]`);
        const input = document.querySelector(`.service-value[data-id="${id}"]`);

        if (select && input) {
            const selectedOption = select.options[select.selectedIndex];
            const value = selectedOption.getAttribute('data-value');
            input.value = value ? parseFloat(value).toFixed(2).replace('.', ',') : '';
            this.calculateServicesTotal();
        }
    },

    calculateServicesTotal: function() {
        let total = 0;
        document.querySelectorAll('.service-value').forEach(input => {
            total += this.parseCurrency(input.value);
        });
        document.getElementById('total-services').innerText = total.toFixed(2).replace('.', ',');
    },

    addProduct: function() {
        this.productsCounter++;
        const id = this.productsCounter;
        const grid = document.getElementById('products-grid');

        const stock = this.cachedData.stock || [];
        const options = stock.length === 0
            ? '<option value="">Nenhum produto cadastrado</option>'
            : '<option value="">Selecione...</option>' + stock.map(i => `<option value="${i.id}">${i.name} (${i.quantity} un.)</option>`).join('');

        const div = document.createElement('div');
        div.className = 'product-item';
        div.id = `product-${id}`;
        div.innerHTML = `
            <div class="row align-items-end">
                <div class="col-md-8 mb-2">
                    <label class="form-label small">Produto</label>
                    <select class="form-select form-select-sm product-select" data-id="${id}">
                        ${options}
                    </select>
                </div>
                <div class="col-md-2 mb-2">
                    <label class="form-label small">Qtd</label>
                    <input type="number" class="form-control form-control-sm product-qty" data-id="${id}" value="1" min="1">
                </div>
                <div class="col-md-2 mb-2">
                    <button class="btn btn-sm btn-danger w-100" onclick="app.removeProduct(${id})">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            </div>
        `;

        grid.appendChild(div);
    },

    removeProduct: function(id) {
        const elem = document.getElementById(`product-${id}`);
        if (elem) elem.remove();
    },

    // ==================== AGENDAMENTOS ====================
    async loadAgendaOptions() {
        // Carregar pets
        let petsResult = this.cachedData.pets;
        if (!petsResult || petsResult.length === 0) {
            const result = await this.apiCall('pets_list');
            petsResult = result.pets || [];
            this.cachedData.pets = petsResult;
        }

        const selPet = document.getElementById('ag-pet');
        if (petsResult.length === 0) {
            selPet.innerHTML = '<option value="">Cadastre um Pet primeiro</option>';
        } else {
            selPet.innerHTML = '<option value="">Selecione o Pet</option>' +
                petsResult.map(p => `<option value="${p.id}">${p.name} - ${p.owner}</option>`).join('');
        }

        // Carregar funcionários
        let staffResult = this.cachedData.staff;
        if (!staffResult || staffResult.length === 0) {
            const result = await this.apiCall('staff_list');
            staffResult = result.staff || [];
            this.cachedData.staff = staffResult;
        }

        const selStaff = document.getElementById('ag-staff');
        if (staffResult.length === 0) {
            selStaff.innerHTML = '<option value="">Cadastre um Profissional primeiro</option>';
        } else {
            selStaff.innerHTML = '<option value="">Nenhum</option>' +
                staffResult.map(s => `<option value="${s.id}">${s.name} - ${s.role || 'Funcionário'}</option>`).join('');
        }

        // Carregar estoque para produtos
        const stockResult = await this.apiCall('stock_list');
        this.cachedData.stock = stockResult.stock || [];
    },

    async saveAppointment() {
        const petId = document.getElementById('ag-pet').value;
        const staffId = document.getElementById('ag-staff').value;
        const date = document.getElementById('ag-date').value;
        const time = document.getElementById('ag-time').value;

        if (!petId || !date || !time) {
            return this.toast("Preencha Pet, Data e Horário!");
        }

        // Coletar serviços
        const services = [];
        document.querySelectorAll('.service-select').forEach((select) => {
            const id = select.dataset.id;
            const value = document.querySelector(`.service-value[data-id="${id}"]`).value;
            if (select.value && value) {
                services.push({
                    name: select.value,
                    value: this.parseCurrency(value)
                });
            }
        });

        if (services.length === 0) {
            return this.toast("Adicione pelo menos um serviço!");
        }

        // Coletar produtos
        const products = [];
        const stock = this.cachedData.stock;

        document.querySelectorAll('.product-select').forEach((select) => {
            const id = select.dataset.id;
            const qty = parseInt(document.querySelector(`.product-qty[data-id="${id}"]`).value);

            if (select.value && qty > 0) {
                const product = stock.find(p => p.id == select.value);
                if (product) {
                    if (product.quantity < qty) {
                        this.toast(`Estoque insuficiente de ${product.name}!`);
                        return;
                    }

                    products.push({
                        productId: product.id,
                        productName: product.name,
                        qty: qty,
                        cost: (product.cost || 0) * qty
                    });
                }
            }
        });

        const appointmentData = {
            petId: parseInt(petId),
            staffId: staffId ? parseInt(staffId) : null,
            date,
            time,
            services,
            products
        };

        const result = await this.apiCall('appointments_save', appointmentData);

        if (result.success) {
            this.toast("Agendamento confirmado!");
            this.renderAgendaList();
            this.updateDashboard();
            this.renderChart(); // Atualizar gráfico instantaneamente
            this.cancelEdit('agenda');

            // Recarregar estoque
            const stockResult = await this.apiCall('stock_list');
            this.cachedData.stock = stockResult.stock || [];
        } else {
            this.toast(result.error || 'Erro ao salvar agendamento');
        }
    },

    async renderAgendaList() {
        const list = document.getElementById('agenda-list');
        const result = await this.apiCall('appointments_list');

        if (!result.appointments) {
            list.innerHTML = '<div class="empty-state"><div class="empty-icon"><i class="bi bi-calendar-check"></i></div><p>Nenhum agendamento cadastrado.</p></div>';
            return;
        }

        let appts = result.appointments;
        this.cachedData.appointments = appts;

        if (this.currentAgendaFilter) {
            appts = appts.filter(a => a.appointment_date === this.currentAgendaFilter);
        }

        if (appts.length === 0) {
            const msg = this.currentAgendaFilter
                ? `<p>Nenhum agendamento para ${new Date(this.currentAgendaFilter + 'T00:00:00').toLocaleDateString('pt-BR')}.</p>`
                : '<p>Nenhum agendamento cadastrado.</p>';
            list.innerHTML = `<div class="empty-state"><div class="empty-icon"><i class="bi bi-calendar-check"></i></div>${msg}</div>`;
            return;
        }

        const pets = this.cachedData.pets;
        const staff = this.cachedData.staff;
        const today = new Date().toISOString().split('T')[0];

        list.innerHTML = appts.sort((a, b) => {
            const dateCompare = new Date(a.appointment_date) - new Date(b.appointment_date);
            if (dateCompare !== 0) return dateCompare;
            return (a.appointment_time || '').localeCompare(b.appointment_time || '');
        }).map(a => {
            const pet = pets.find(p => p.id == a.pet_id);
            const worker = staff.find(s => s.id == a.staff_id);
            const isToday = a.appointment_date === today;
            const total = a.total_value || 0;

            let servicesHtml = '';
            if (a.services && a.services.length > 0) {
                servicesHtml = '<div class="mt-2"><strong>Serviços:</strong><ul class="mb-0">';
                a.services.forEach(s => {
                    servicesHtml += `<li>${s.name} - R$ ${parseFloat(s.value).toFixed(2)}</li>`;
                });
                servicesHtml += '</ul></div>';
            }

            let productsHtml = '';
            if (a.products && a.products.length > 0) {
                productsHtml = '<div class="mt-2"><strong>Produtos:</strong><ul class="mb-0">';
                a.products.forEach(p => {
                    productsHtml += `<li>${p.productName} (${p.qty} un.)</li>`;
                });
                productsHtml += '</ul></div>';
            }

            return `
                <div class="list-item ${isToday ? 'today-appointment' : ''}">
                    <div class="d-flex justify-content-between align-items-start mb-2 flex-wrap gap-2">
                        <div>
                            <h5 class="mb-1">
                                ${isToday ? '<i class="bi bi-exclamation-circle-fill text-warning"></i> ' : '<i class="bi bi-heart-fill text-danger"></i> '}
                                ${pet ? pet.name : 'Pet não encontrado'}
                                ${isToday ? '<span class="badge bg-warning ms-2">HOJE</span>' : ''}
                            </h5>
                        </div>
                        <span class="badge bg-success">R$ ${parseFloat(total).toFixed(2)}</span>
                    </div>
                    <div class="small text-muted">
                        <div><i class="bi bi-calendar3"></i> <strong>${new Date(a.appointment_date + 'T00:00:00').toLocaleDateString('pt-BR')}</strong> às <strong>${a.appointment_time || '00:00'}</strong></div>
                        ${pet ? `<div><i class="bi bi-person"></i> Dono: ${pet.owner}${pet.phone ? ` - ${pet.phone}` : ''}</div>` : ''}
                        ${worker ? `<div><i class="bi bi-person-badge"></i> Profissional: ${worker.name} (${worker.role})</div>` : ''}
                        ${servicesHtml}
                        ${productsHtml}
                    </div>
                    <div class="d-flex gap-2 mt-3">
                        <button class="btn btn-sm btn-danger w-100" onclick="app.deleteAppointment(${a.id})">
                            <i class="bi bi-trash"></i> Cancelar Agendamento
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    },

    async deleteAppointment(id) {
        if (!confirm("Cancelar agendamento?")) return;

        const result = await this.apiCall('appointments_delete', { id });

        if (result.success) {
            this.renderAgendaList();
            this.updateDashboard();
            this.renderChart(); // Atualizar gráfico instantaneamente
            this.toast("Agendamento cancelado.");
        }
    },

    filterAgendaByDate: function() {
        const filterDate = document.getElementById('agenda-filter-date').value;
        this.currentAgendaFilter = filterDate;
        this.renderAgendaList();
    },

    clearAgendaFilter: function() {
        this.currentAgendaFilter = null;
        document.getElementById('agenda-filter-date').value = '';
        this.renderAgendaList();
    },

    showTodayAppointments: function() {
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('agenda-filter-date').value = today;
        this.currentAgendaFilter = today;
        this.renderAgendaList();
    },

    async checkTodayAppointments() {
        const today = new Date().toISOString().split('T')[0];
        const result = await this.apiCall('appointments_list');

        if (!result.appointments) return;

        const appts = result.appointments.filter(a => a.appointment_date === today);

        if (appts.length > 0) {
            const pets = this.cachedData.pets;
            const staff = this.cachedData.staff;

            const alertDiv = document.getElementById('today-alert');
            const summaryDiv = document.getElementById('today-appointments-summary');

            let html = `<strong>${appts.length} agendamento(s) para hoje:</strong><ul class="mb-0 mt-2">`;

            appts.sort((a, b) => (a.appointment_time || '').localeCompare(b.appointment_time || '')).forEach(a => {
                const pet = pets.find(p => p.id == a.pet_id);
                const worker = staff.find(s => s.id == a.staff_id);
                const timeStr = a.appointment_time ? ` às ${a.appointment_time}` : '';
                const totalValue = a.total_value || 0;
                html += `<li><strong>${pet ? pet.name : 'Pet'}</strong> - R$ ${parseFloat(totalValue).toFixed(2)}${timeStr}${worker ? ` (${worker.name})` : ''}</li>`;
            });

            html += '</ul>';
            summaryDiv.innerHTML = html;
            alertDiv.classList.remove('d-none');
        } else {
            document.getElementById('today-alert').classList.add('d-none');
        }
    },

    // ==================== FINANCEIRO ====================
    async renderExpenses() {
        const list = document.getElementById('expense-list');
        const result = await this.apiCall('finances_list');

        if (!result.finances || result.finances.length === 0) {
            list.innerHTML = '<div class="empty-state"><div class="empty-icon"><i class="bi bi-cash-coin"></i></div><p>Sem lançamentos financeiros.</p></div>';
            return;
        }

        this.cachedData.finances = result.finances;

        list.innerHTML = result.finances.sort((a, b) => new Date(b.transaction_date) - new Date(a.transaction_date)).map(e => {
            const isInc = e.type === 'income';
            const sign = isInc ? '+' : '-';
            const colorClass = isInc ? 'success' : 'danger';
            const borderColor = isInc ? 'var(--accent)' : 'var(--danger)';
            const icon = isInc ? 'bi-arrow-up-circle' : 'bi-arrow-down-circle';

            return `
                <div class="list-item" style="border-left-color: ${borderColor}">
                    <div class="d-flex justify-content-between align-items-start mb-2 flex-wrap gap-2">
                        <h5 class="mb-1"><i class="bi ${icon} text-${colorClass}"></i> ${e.description}</h5>
                        <span class="badge bg-${colorClass}">
                            ${sign} R$ ${parseFloat(e.value).toFixed(2)}
                        </span>
                    </div>
                    <div class="small text-muted">
                        <i class="bi bi-calendar3"></i> ${new Date(e.transaction_date + 'T00:00:00').toLocaleDateString('pt-BR')} -
                        ${isInc ? 'Receita Extra' : 'Despesa'}
                    </div>
                    <div class="d-flex gap-2 mt-3">
                        <button class="btn btn-sm btn-primary flex-fill" onclick="app.editExpense(${e.id})">
                            <i class="bi bi-pencil"></i> Editar
                        </button>
                        <button class="btn btn-sm btn-danger flex-fill" onclick="app.deleteExpense(${e.id})">
                            <i class="bi bi-trash"></i> Excluir
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    },

    async saveExpense() {
        const id = parseInt(document.getElementById('fin-id').value) || 0;
        const desc = document.getElementById('fin-desc').value.trim();
        const val = this.parseCurrency(document.getElementById('fin-value').value);
        const date = document.getElementById('fin-date').value;
        const type = document.getElementById('fin-type').value;

        if (!desc || isNaN(val) || !date) return this.toast("Preencha todos os campos!");

        const financeData = {
            id: id > 0 ? id : undefined,
            type,
            desc,
            val,
            date
        };

        const result = await this.apiCall('finances_save', financeData);

        if (result.success) {
            this.toast(id > 0 ? "Lançamento atualizado!" : (type === 'income' ? "Receita lançada!" : "Despesa lançada!"));
            document.getElementById('fin-id').value = '';
            document.getElementById('fin-desc').value = '';
            document.getElementById('fin-value').value = '';
            document.getElementById('fin-date').value = new Date().toISOString().split('T')[0];
            document.getElementById('fin-type').value = 'expense';

            this.cancelEdit('finance');
            this.renderExpenses();
            this.updateDashboard();
            this.renderChart(); // Atualizar gráfico instantaneamente
        } else {
            this.toast(result.error || 'Erro ao salvar lançamento');
        }
    },

    editExpense: function(id) {
        const item = this.cachedData.finances.find(x => x.id === id);
        if (!item) return;

        this.editMode['finance'] = true;
        document.getElementById('fin-id').value = item.id;
        document.getElementById('fin-type').value = item.type || 'expense';
        document.getElementById('fin-desc').value = item.description;
        document.getElementById('fin-value').value = parseFloat(item.value).toFixed(2).replace('.', ',');
        document.getElementById('fin-date').value = item.transaction_date;
        document.getElementById('btn-cancel-fin').classList.remove('d-none');

        this.updateFinanceButton();
        document.querySelector('#finance-screen .form-section').scrollIntoView({ behavior: 'smooth', block: 'center' });
    },

    async deleteExpense(id) {
        if (!confirm("Excluir lançamento?")) return;

        const result = await this.apiCall('finances_delete', { id });

        if (result.success) {
            this.renderExpenses();
            this.updateDashboard();
            this.renderChart(); // Atualizar gráfico instantaneamente
            this.toast("Lançamento excluído.");
        }
    },

    updateFinanceButton: function() {
        const type = document.getElementById('fin-type').value;
        const btn = document.getElementById('btn-save-fin');
        const isEditing = document.getElementById('fin-id').value !== '';

        if (type === 'income') {
            btn.innerHTML = '<i class="bi bi-arrow-up-circle"></i> ' + (isEditing ? 'ATUALIZAR RECEITA' : 'LANÇAR RECEITA');
            btn.className = 'btn btn-success flex-fill';
        } else {
            btn.innerHTML = '<i class="bi bi-arrow-down-circle"></i> ' + (isEditing ? 'ATUALIZAR DESPESA' : 'LANÇAR DESPESA');
            btn.className = 'btn btn-danger flex-fill';
        }
    },

    // ==================== DASHBOARD ====================
    async updateDashboard() {
        const filterValue = document.getElementById('month-filter')?.value;
        if (!filterValue) return;

        const result = await this.apiCall('dashboard_stats', { month: filterValue });

        if (result.stats) {
            const stats = result.stats;

            document.getElementById('dash-revenue').innerText = `R$ ${parseFloat(stats.total_revenue).toFixed(2)}`;
            document.getElementById('dash-expenses').innerText = `R$ ${parseFloat(stats.expenses).toFixed(2)}`;

            const profit = stats.profit;
            const elP = document.getElementById('dash-profit');
            elP.innerText = `R$ ${parseFloat(profit).toFixed(2)}`;
            elP.className = `stat-value ${profit >= 0 ? 'text-success' : 'text-danger'}`;
            elP.parentElement.className = `stat-card ${profit >= 0 ? 'border-success' : 'border-danger'} border-3`;
        }
    },

    async renderChart() {
        const canvas = document.getElementById('financeChart');
        if (!canvas) return;

        const result = await this.apiCall('dashboard_chart');

        if (!result.chartData) return;

        const ctx = canvas.getContext('2d');
        const chartData = result.chartData;

        if (this.chartInstance) {
            this.chartInstance.destroy();
        }

        this.chartInstance = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: chartData.labels,
                datasets: [
                    {
                        label: 'Receitas',
                        data: chartData.revenue,
                        backgroundColor: '#27ae60',
                        borderRadius: 8
                    },
                    {
                        label: 'Despesas',
                        data: chartData.expenses,
                        backgroundColor: '#c0392b',
                        borderRadius: 8
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                aspectRatio: 2,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            font: { size: 13, weight: 'bold' }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': R$ ' + context.parsed.y.toFixed(2);
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: '#f0f0f0' },
                        ticks: {
                            callback: function(value) {
                                return 'R$ ' + value.toFixed(0);
                            }
                        }
                    },
                    x: { grid: { display: false } }
                }
            }
        });
    },

    // ==================== BACKUP ====================
    async exportData() {
        const result = await this.apiCall('backup_export');

        if (result.backup) {
            const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(result.backup, null, 2));
            const a = document.createElement('a');
            a.href = dataStr;
            a.download = `backup_${new Date().toISOString().slice(0, 10)}.json`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            this.toast("Backup baixado com sucesso!");
        } else {
            this.toast("Erro ao gerar backup");
        }
    },

    importData: function(input) {
        const file = input.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = async (e) => {
            try {
                const backup = JSON.parse(e.target.result);

                const result = await this.apiCall('backup_import', { backup });

                if (result.success) {
                    this.toast(result.message || 'Backup restaurado!');
                    setTimeout(() => this.nav('main-screen'), 1500);
                } else {
                    this.toast(result.error || "Erro ao restaurar backup");
                }
            } catch (err) {
                this.toast("Erro ao ler arquivo de backup.");
                console.error(err);
            }
        };
        reader.readAsText(file);
    },

    async clearAllData() {
        if (confirm("TEM CERTEZA? Isso apagará todos os dados da loja. Esta ação não pode ser desfeita!")) {
            const emptyBackup = {
                pets: [],
                staff: [],
                stock: [],
                custom_services: [],
                appointments: [],
                finances: []
            };

            const result = await this.apiCall('backup_import', { backup: emptyBackup });

            if (result.success) {
                this.toast("Todos os dados foram apagados.");
                setTimeout(() => this.nav('main-screen'), 1000);
            } else {
                this.toast("Erro ao limpar dados");
            }
        }
    }
};

// Inicializar quando o DOM estiver pronto
window.addEventListener('DOMContentLoaded', () => app.init());
